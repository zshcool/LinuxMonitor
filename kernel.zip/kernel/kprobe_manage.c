#include "kprobe_manage.h"
#include "log_manage.h"
#include "procfs_manage.h"
#include "manage_pt_regs.h"

#include <linux/string.h>

static struct kprobe kps[MAX_PROBES];
static int count = 0;

static char *probe_names[] = {"sys_execve"};


int init_kprobes(void)
{
    int i, probe_num;
    int ret = 0;
    for(i = 0; i < MAX_PROBES; ++i)
    {
        kps[i].symbol_name = NULL;
    }

    //probe_names is an array
    probe_num = 1;//sizeof(probe_names);
    printk("default probe_num:%d\n", probe_num);

    if((probe_num > 0))
    {
        for(i = 0; i < probe_num; i++)
        {   
            init_kprobe(&kps[count], probe_names[i], handle_post);
            count++;
        }
    }
    
    for(i = 0; i < MAX_PROBES; i++)
    {
        if(kps[i].symbol_name != NULL)
        {
            ret = register_kprobe(&kps[i]);
            if(ret < 0)
            {
                printk("register failed, errno:%d\n", ret);
                goto end;
            }
            printk("resgistry:%s success!\n", kps[i].symbol_name);
        }
    }
   
    ret = 0;

end:
    if(ret < 0)
        destroy_kprobes();

    return ret;
}


void destroy_kprobes(void)
{
    int i;
    for(i = 0; i < MAX_PROBES; i++)
    {
        if(kps[i].symbol_name != NULL)
        {
            unregister_kprobe(&kps[i]);
        }
    }
}


int handle_pre(struct kprobe *p, struct pt_regs *regs)
{
    return 0;
}


void handle_post(struct kprobe *p, struct pt_regs *regs, unsigned long flags)
{
    struct log_item *item;    

    if(is_monitor(current->pid))
    {
        printk("monitor process filter!\n");
        return;
    }

    item = get_log_item();
    
    item->pid = current->pid;
    item->ppid = current->parent->pid;
    strcpy(item->syscall, p->symbol_name, strlen(p->symbol_name) + 1);
    strcpy(item->name, current->comm, strlen(current->comm) + 1);
    strcpy(item->pname, current->parrent->comm, strlen(current->parrent->comm) + 1);
    mange_regs(p->symbol_name, regs, item->buf, LOGSIZE);

    


    printk("func:%s", p->symbol_name);
}


int handle_fault(struct kprobe *p, struct pt_regs *regs, int trapnr)
{
    return 0;
}


void init_kprobe(struct kprobe *p, char* name, posthandle handle)
{
    p->symbol_name = name;
    p->pre_handler = handle_pre;
    p->post_handler = handle;
    p->fault_handler = handle_fault;
}


void mange_regs(char *syscall, struct pt_regs *regs, char* buf, int len)
{
    int left = len;
    int 
    if (strcmp(syscall, "sys_execve"))
    {
        char *path;
        char **argv;
        char **tmp;

        path = (char*)get_arg1(regs);
        argv = (char**)get_arg2(regs);

        strcat(buf, "objpath");
        strcat(buf, COLON);
        strcat(buf, path);
        strcat(buf, SPLIT);
        strcat(buf, "command");
        strcat(buf, COLON);

        tmp = argv;
        strcat(buf, path);
        while(*tmp != NULL)
        {
            strcat(buf, " ");
            strcat(buf, *tmp);
            tmp++;
        }
    }
    else if(strcmp(syscall, "sys_connect"))
    {

    }
}